// Contains download-related functionality moved from script.js
let downloadedFiles = [];
let currentUser = null;

export function initDownloads() {
    downloadedFiles = JSON.parse(localStorage.getItem('uploadedDocuments') || '[]').map(file => ({
        ...file,
        uploadDate: new Date(file.uploadDate)
    }));
    currentUser = localStorage.getItem('currentUser');
}

export function addToDownloadsList(fileInfo) {
    if (!currentUser) {
        currentUser = 'user_' + Date.now();
        localStorage.setItem('currentUser', currentUser);
    }
    
    if (fileInfo.file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const fileData = {
                ...fileInfo,
                fileData: e.target.result,
                uploaderId: currentUser,
                uploadDate: new Date()
            };
            delete fileData.file;
            
            downloadedFiles.push(fileData);
            localStorage.setItem('uploadedDocuments', JSON.stringify(downloadedFiles));
            renderDownloadsList();
        };
        reader.readAsDataURL(fileInfo.file);
    } else {
        downloadedFiles.push(fileInfo);
        localStorage.setItem('uploadedDocuments', JSON.stringify(downloadedFiles));
        renderDownloadsList();
    }
}

export function renderDownloadsList(filteredFiles = null) {
    const files = filteredFiles || downloadedFiles;
    const downloadsList = document.getElementById('downloadsList');
    downloadsList.innerHTML = '';
    
    if (files.length === 0) {
        downloadsList.innerHTML = '<div class="no-results">No uploads found</div>';
        return;
    }

    files.forEach((fileInfo, index) => {
        const formattedDate = new Date(fileInfo.uploadDate).toLocaleDateString('en-US', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });
        
        const isUploader = fileInfo.uploaderId === currentUser;
        
        const downloadItem = document.createElement('div');
        downloadItem.className = 'download-item';
        downloadItem.innerHTML = `
            <div class="download-info">
                <h3>${fileInfo.subject}</h3>
                <p><strong>Faculty:</strong> ${fileInfo.school}</p>
                <p><strong>Department:</strong> ${fileInfo.department}</p>
                <p><strong>Level:</strong> ${fileInfo.level} | <strong>Semester:</strong> ${fileInfo.semester} | <strong>Year:</strong> ${fileInfo.year}</p>
                <p><strong>File:</strong> ${fileInfo.fileName}</p>
                <p><strong>Uploaded:</strong> ${formattedDate}</p>
            </div>
            <div class="action-buttons">
                <button class="download-btn" onclick="window.location.href='${fileInfo.fileData}'" download="${fileInfo.fileName}">
                    Download
                </button>
                <button class="share-btn" data-info="${encodeURIComponent(JSON.stringify({
                    title: fileInfo.subject,
                    text: `Check out this ${fileInfo.level} ${fileInfo.semester} question paper for ${fileInfo.subject} from ${fileInfo.school}, ${fileInfo.department}`,
                    url: window.location.href,
                    file: fileInfo.fileData,
                    fileName: fileInfo.fileName
                }))}">
                    Share
                </button>
                ${isUploader ? `
                    <button class="edit-btn" data-index="${index}">
                        Edit
                    </button>
                    <button class="delete-btn" data-index="${index}">
                        Delete
                    </button>
                ` : ''}
            </div>
        `;
        downloadsList.appendChild(downloadItem);
    });

    // Add share functionality
    const shareButtons = document.querySelectorAll('.share-btn');
    shareButtons.forEach(button => {
        button.addEventListener('click', async (e) => {
            const shareData = JSON.parse(decodeURIComponent(e.target.dataset.info));
            
            // Create share modal
            const modalHTML = `
                <div class="share-modal">
                    <div class="share-modal-content">
                        <h3>${shareData.title}</h3>
                        <p style="margin-bottom: 15px; color: #666;">${shareData.text}</p>
                        <div class="share-options">
                            <button class="share-option" data-platform="whatsapp">
                                Share on WhatsApp
                            </button>
                            <button class="share-option" data-platform="telegram">
                                Share on Telegram
                            </button>
                            <button class="share-option" data-platform="twitter">
                                Share on Twitter
                            </button>
                            <button class="share-option" data-platform="facebook">
                                Share on Facebook
                            </button>
                            <button class="share-option" data-platform="copy">
                                Copy Link
                            </button>
                            ${navigator.share ? `
                                <button class="share-option" data-platform="native">
                                    Share via Device
                                </button>
                            ` : ''}
                        </div>
                        <button class="close-modal">Close</button>
                    </div>
                </div>
            `;
            
            // Add modal to page
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            
            const modal = document.querySelector('.share-modal');
            const closeBtn = modal.querySelector('.close-modal');
            const shareOptions = modal.querySelectorAll('.share-option');
            
            closeBtn.onclick = () => modal.remove();
            
            shareOptions.forEach(option => {
                option.onclick = async () => {
                    const platform = option.dataset.platform;
                    const text = shareData.text;
                    const url = shareData.url;
                    
                    switch(platform) {
                        case 'whatsapp':
                            window.open(`https://wa.me/?text=${encodeURIComponent(text + '\n\n' + url)}`);
                            break;
                        case 'telegram':
                            window.open(`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`);
                            break;
                        case 'twitter':
                            window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`);
                            break;
                        case 'facebook':
                            window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`);
                            break;
                        case 'copy':
                            await navigator.clipboard.writeText(`${text}\n\n${url}`);
                            alert('Link copied to clipboard!');
                            break;
                        case 'native':
                            try {
                                await navigator.share(shareData);
                            } catch (err) {
                                console.warn('Share failed:', err);
                            }
                            break;
                    }
                    modal.remove();
                };
            });
        });
    });

    // Add delete and edit functionality for uploaders
    const deleteButtons = document.querySelectorAll('.delete-btn');
    const editButtons = document.querySelectorAll('.edit-btn');

    deleteButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const index = parseInt(e.target.dataset.index);
            if (downloadedFiles[index].uploaderId === currentUser) {
                if (confirm('Are you sure you want to delete this upload?')) {
                    downloadedFiles.splice(index, 1);
                    localStorage.setItem('uploadedDocuments', JSON.stringify(downloadedFiles));
                    renderDownloadsList();
                }
            }
        });
    });

    editButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const index = parseInt(e.target.dataset.index);
            if (downloadedFiles[index].uploaderId === currentUser) {
                // Populate form with existing data
                const file = downloadedFiles[index];
                document.getElementById('school').value = file.school;
                document.getElementById('department').value = file.department;
                document.getElementById('subject').value = file.subject;
                document.getElementById('level').value = file.level;
                document.getElementById('semester').value = file.semester;
                
                // Remove old entry
                downloadedFiles.splice(index, 1);
                localStorage.setItem('uploadedDocuments', JSON.stringify(downloadedFiles));
                
                // Show form for editing
                document.getElementById('uploadForm').classList.remove('hidden');
                document.getElementById('uploadAnotherBtn').classList.add('hidden');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    });
}

export function setupDownloadControls(elements) {
    const searchInput = elements.searchInput;
    const sortButtons = elements.sortButtons;
    const downloadsList = elements.downloadsList;

    // Search functionality
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const filteredFiles = downloadedFiles.filter(file => 
            file.school.toLowerCase().includes(searchTerm) ||
            file.department.toLowerCase().includes(searchTerm) ||
            file.subject.toLowerCase().includes(searchTerm) ||
            file.level.toLowerCase().includes(searchTerm) ||
            file.semester.toLowerCase().includes(searchTerm) ||
            file.year.toString().includes(searchTerm)
        );
        
        if (filteredFiles.length === 0 && searchTerm) {
            downloadsList.innerHTML = '<div class="no-results">No documents found matching your search criteria</div>';
        } else {
            renderDownloadsList(filteredFiles);
        }
    });

    // Sorting functionality
    let currentSort = 'date';
    sortButtons.addEventListener('click', (e) => {
        if (!e.target.classList.contains('sort-btn')) return;
        
        // Update active button
        sortButtons.querySelectorAll('.sort-btn').forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
        
        const sortBy = e.target.dataset.sort;
        currentSort = sortBy;
        
        const sortedFiles = [...downloadedFiles].sort((a, b) => {
            switch(sortBy) {
                case 'date':
                    return b.uploadDate - a.uploadDate;
                case 'faculty':
                    return a.school.localeCompare(b.school);
                case 'department':
                    return a.department.localeCompare(b.department);
                case 'level':
                    return a.level.localeCompare(b.level);
                case 'semester':
                    return a.semester.localeCompare(b.semester);
                default:
                    return 0;
            }
        });
        
        renderDownloadsList(sortedFiles);
    });
}
// Contains event handlers moved from script.js
import { addToDownloadsList, renderDownloadsList } from './downloads.js';
import { departmentsBySchool } from '/config.js';

export function setupFormHandlers(elements) {
    const {
        dropZone,
        fileInput,
        browseBtn,
        preview,
        imagePreview,
        removeBtn,
        uploadForm,
        uploadAnotherBtn,
        yearSelect,
        yearValueContainer,
        yearValueInput,
        schoolSelect,
        departmentSelect,
        loaderOverlay
    } = elements;

    // Handle drag and drop events
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => {
            dropZone.classList.add('drag-over');
        });
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => {
            dropZone.classList.remove('drag-over');
        });
    });

    // Handle file drop
    dropZone.addEventListener('drop', (e) => {
        const file = e.dataTransfer.files[0];
        handleFile(file);
    });

    // Handle file selection via button
    browseBtn.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        handleFile(file);
    });

    // Remove preview
    removeBtn.addEventListener('click', () => {
        preview.classList.add('hidden');
        dropZone.classList.remove('hidden');
        fileInput.value = '';
        imagePreview.src = '';
    });

    function handleFile(file) {
        if (!file) return;

        const maxSize = 10 * 1024 * 1024; // 10MB
        if (file.size > maxSize) {
            alert('File size must be less than 10MB');
            return;
        }

        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                imagePreview.src = e.target.result;
                preview.classList.remove('hidden');
                dropZone.classList.add('hidden');
            };
            reader.readAsDataURL(file);
        } else {
            const reader = new FileReader();
            reader.onload = () => {
                imagePreview.src = getDocumentIcon(file.type);
                const fileNameDisplay = document.createElement('p');
                fileNameDisplay.textContent = file.name;
                fileNameDisplay.className = 'file-name';
                imagePreview.parentElement.appendChild(fileNameDisplay);
                preview.classList.remove('hidden');
                dropZone.classList.add('hidden');
            };
            reader.readAsArrayBuffer(file);
        }
    }

    function getDocumentIcon(fileType) {
        const icons = {
            'application/pdf': 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiNmZjAwMDAiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cGF0aCBkPSJNMTQgMkg2YTIgMiAwIDAgMC0yIDJ2MTZhMiAyIDAgMCAwIDIgMmgxMmEyIDIgMCAwIDAgMi0yVjh6Ii8+PHBvbHlsaW5lIHBvaW50cz0iMTQgMiAxNCA4IDIwIDgiLz48L3N2Zz4=',
            'application/msword': 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMDAwZmYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cGF0aCBkPSJNMTQgMkg2YTIgMiAwIDAgMC0yIDJ2MTZhMiAyIDAgMCAwIDIgMmgxMmEyIDIgMCAwIDAgMi0yVjh6Ii8+PHBvbHlsaW5lIHBvaW50cz0iMTQgMiAxNCA4IDIwIDgiLz48L3N2Zz4=',
            'application/vnd.ms-excel': 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiMwMGZmMDAiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cGF0aCBkPSJNMTQgMkg2YTIgMiAwIDAgMC0yIDJ2MTZhMiAyIDAgMCAwIDIgMmgxMmEyIDIgMCAwIDAgMi0yVjh6Ii8+PHBvbHlsaW5lIHBvaW50cz0iMTQgMiAxNCA4IDIwIDgiLz48L3N2Zz4='
        };
        return icons[fileType] || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiM2NjY2NjYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cGF0aCBkPSJNMTQgMkg2YTIgMiAwIDAgMC0yIDJ2MTZhMiAyIDAgMCAwIDIgMmgxMmEyIDIgMCAwIDAgMi0yVjh6Ii8+PHBvbHlsaW5lIHBvaW50cz0iMTQgMiAxNCA4IDIwIDgiLz48L3N2Zz4=';
    }

    // Year value input handling
    yearSelect.addEventListener('change', (e) => {
        if (e.target.value) {
            yearValueContainer.classList.remove('hidden');
        } else {
            yearValueContainer.classList.add('hidden');
            yearValueInput.value = '';
        }
    });

    // Department dropdown population
    schoolSelect.addEventListener('change', (e) => {
        const selectedSchool = e.target.value;
        const departments = departmentsBySchool[selectedSchool] || [];
        
        departmentSelect.innerHTML = '';
        departments.forEach(dept => {
            const option = document.createElement('option');
            option.value = dept === "Select Department" ? "" : dept;
            option.textContent = dept;
            departmentSelect.appendChild(option);
        });
    });

    // Form submission
    uploadForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = {
            school: schoolSelect.value,
            department: departmentSelect.value,
            subject: document.getElementById('subject').value,
            level: document.getElementById('level').value,
            semester: document.getElementById('semester').value,
            yearLevel: document.getElementById('year').value,
            yearValue: yearValueInput.value,
            file: fileInput.files[0],
            uploadDate: new Date()
        };

        if (!Object.values(formData).every(val => val)) {
            alert('Please fill all fields and upload a file');
            return;
        }

        loaderOverlay.style.display = 'flex';
        uploadForm.classList.add('hidden');

        try {
            await new Promise(resolve => setTimeout(resolve, 3000));
            addToDownloadsList(formData);
            alert('Upload successful!');
            uploadAnotherBtn.classList.remove('hidden');
        } catch (error) {
            alert('Error uploading file: ' + error.message);
            uploadForm.classList.remove('hidden');
        } finally {
            loaderOverlay.style.display = 'none';
        }
    });

    // Upload another button
    uploadAnotherBtn.addEventListener('click', () => {
        uploadForm.reset();
        preview.classList.add('hidden');
        dropZone.classList.remove('hidden');
        imagePreview.src = '';
        uploadAnotherBtn.classList.add('hidden');
        uploadForm.classList.remove('hidden');
    });
}
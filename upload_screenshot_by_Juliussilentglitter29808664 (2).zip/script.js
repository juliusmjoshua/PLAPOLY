// Main script file - now much smaller!
import { setupFormHandlers } from './handlers.js';
import { initDownloads, setupDownloadControls } from './downloads.js';

document.addEventListener('DOMContentLoaded', () => {
    // Initialize downloads
    initDownloads();

    // Get DOM elements
    const elements = {
        dropZone: document.getElementById('dropZone'),
        fileInput: document.getElementById('fileInput'),
        browseBtn: document.getElementById('browseBtn'),
        preview: document.getElementById('preview'),
        imagePreview: document.getElementById('imagePreview'),
        removeBtn: document.getElementById('removeBtn'),
        uploadForm: document.getElementById('uploadForm'),
        uploadAnotherBtn: document.getElementById('uploadAnotherBtn'),
        downloadsList: document.getElementById('downloadsList'),
        yearSelect: document.getElementById('year'),
        yearValueContainer: document.getElementById('yearValueContainer'),
        yearValueInput: document.getElementById('yearValue'),
        schoolSelect: document.getElementById('school'),
        departmentSelect: document.getElementById('department'),
        loaderOverlay: document.querySelector('.loader-overlay'),
        searchInput: document.getElementById('searchInput'),
        sortButtons: document.getElementById('sortButtons'),
        downloadsSection: document.querySelector('.downloads-section'),
        toggleDownloadsBtn: document.getElementById('toggleDownloads')
    };

    // Setup handlers
    setupFormHandlers(elements);
    setupDownloadControls(elements);

    // Setup toggle functionality
    elements.toggleDownloadsBtn.addEventListener('click', () => {
        elements.downloadsSection.classList.toggle('hidden');
        const isHidden = elements.downloadsSection.classList.contains('hidden');
        localStorage.setItem('downloadsHidden', isHidden);
    });

    // Restore previous state
    const wasHidden = localStorage.getItem('downloadsHidden') === 'true';
    if (wasHidden) {
        elements.downloadsSection.classList.add('hidden');
    }
});